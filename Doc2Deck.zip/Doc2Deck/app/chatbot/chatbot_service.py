import os
import google.generativeai as genai
from typing import List, Dict

class ChatbotService:
    def __init__(self):
        genai.configure(api_key=os.getenv("GEMINI_API_KEY"))
        self.model = genai.GenerativeModel('gemini-pro')
        self.conversation_history = {}
    
    async def get_response(self, user_id: str, message: str, context: Dict = None) -> str:
        if user_id not in self.conversation_history:
            self.conversation_history[user_id] = []
        
        system_prompt = """You are Doc2Deck AI Assistant, a helpful chatbot for a presentation creation platform. 
        You help users with:
        - Creating better presentations
        - Improving slide content
        - Suggesting design ideas
        - Answering questions about features
        - Providing tips for effective presentations
        
        Be concise, friendly, and helpful."""
        
        context_info = ""
        if context:
            context_info = f"\nUser Context: {context.get('presentations_count', 0)} presentations created."
        
        full_prompt = f"{system_prompt}{context_info}\n\nUser: {message}\nAssistant:"
        
        try:
            response = self.model.generate_content(full_prompt)
            assistant_message = response.text if hasattr(response, 'text') else str(response)
            
            self.conversation_history[user_id].append({"role": "user", "content": message})
            self.conversation_history[user_id].append({"role": "assistant", "content": assistant_message})
            
            if len(self.conversation_history[user_id]) > 20:
                self.conversation_history[user_id] = self.conversation_history[user_id][-20:]
            
            return assistant_message
        except Exception as e:
            print(f"Chatbot error: {e}")
            return "I'm here to help with Doc2Deck! Ask me about creating presentations, using templates, or any features."
    
    def clear_history(self, user_id: str):
        if user_id in self.conversation_history:
            del self.conversation_history[user_id]
    
    async def get_quick_suggestions(self, topic: str) -> List[str]:
        prompt = f"Give 3 brief tips for creating a presentation about '{topic}'. Each tip in one sentence."
        try:
            response = self.model.generate_content(prompt)
            tips = response.text.split('\n')
            return [tip.strip() for tip in tips if tip.strip()][:3]
        except:
            return ["Focus on key points", "Use visuals effectively", "Keep slides simple"]
