from pydantic import BaseModel
from typing import List, Dict

class PPTTemplate(BaseModel):
    id: str
    name: str
    category: str
    thumbnail: str
    colors: Dict[str, str]
    fonts: Dict[str, str]
    layout_style: str
    premium: bool = False

class TemplateManager:
    def __init__(self):
        self.templates = self._init_templates()
    
    def _init_templates(self) -> List[PPTTemplate]:
        return [
            PPTTemplate(id="modern_blue", name="Modern Blue", category="Business", 
                       thumbnail="/static/templates/modern_blue.jpg",
                       colors={"primary": "#2563EB", "secondary": "#60A5FA", "accent": "#DBEAFE", "text": "#1E293B"},
                       fonts={"heading": "Montserrat", "body": "Open Sans"},
                       layout_style="minimal"),
            PPTTemplate(id="elegant_dark", name="Elegant Dark", category="Business",
                       thumbnail="/static/templates/elegant_dark.jpg",
                       colors={"primary": "#0F172A", "secondary": "#334155", "accent": "#F59E0B", "text": "#F8FAFC"},
                       fonts={"heading": "Playfair Display", "body": "Lato"},
                       layout_style="sophisticated", premium=True),
            PPTTemplate(id="vibrant_gradient", name="Vibrant Gradient", category="Creative",
                       thumbnail="/static/templates/vibrant_gradient.jpg",
                       colors={"primary": "#8B5CF6", "secondary": "#EC4899", "accent": "#F59E0B", "text": "#1F2937"},
                       fonts={"heading": "Poppins", "body": "Inter"},
                       layout_style="dynamic", premium=True),
            PPTTemplate(id="minimal_white", name="Minimal White", category="Academic",
                       thumbnail="/static/templates/minimal_white.jpg",
                       colors={"primary": "#FFFFFF", "secondary": "#F3F4F6", "accent": "#3B82F6", "text": "#111827"},
                       fonts={"heading": "Roboto", "body": "Roboto"},
                       layout_style="clean"),
            PPTTemplate(id="corporate_green", name="Corporate Green", category="Business",
                       thumbnail="/static/templates/corporate_green.jpg",
                       colors={"primary": "#059669", "secondary": "#10B981", "accent": "#D1FAE5", "text": "#064E3B"},
                       fonts={"heading": "Raleway", "body": "Source Sans Pro"},
                       layout_style="professional"),
            PPTTemplate(id="tech_purple", name="Tech Purple", category="Technology",
                       thumbnail="/static/templates/tech_purple.jpg",
                       colors={"primary": "#7C3AED", "secondary": "#A78BFA", "accent": "#EDE9FE", "text": "#1F2937"},
                       fonts={"heading": "Space Grotesk", "body": "Inter"},
                       layout_style="modern", premium=True),
            PPTTemplate(id="warm_orange", name="Warm Orange", category="Creative",
                       thumbnail="/static/templates/warm_orange.jpg",
                       colors={"primary": "#EA580C", "secondary": "#FB923C", "accent": "#FED7AA", "text": "#431407"},
                       fonts={"heading": "Nunito", "body": "Nunito Sans"},
                       layout_style="friendly"),
            PPTTemplate(id="ocean_blue", name="Ocean Blue", category="Academic",
                       thumbnail="/static/templates/ocean_blue.jpg",
                       colors={"primary": "#0284C7", "secondary": "#38BDF8", "accent": "#E0F2FE", "text": "#0C4A6E"},
                       fonts={"heading": "Merriweather", "body": "Lora"},
                       layout_style="classic"),
            PPTTemplate(id="sunset_gradient", name="Sunset Gradient", category="Creative",
                       thumbnail="/static/templates/sunset_gradient.jpg",
                       colors={"primary": "#DC2626", "secondary": "#F59E0B", "accent": "#FEF3C7", "text": "#1F2937"},
                       fonts={"heading": "Bebas Neue", "body": "Quicksand"},
                       layout_style="bold", premium=True),
            PPTTemplate(id="forest_green", name="Forest Green", category="Nature",
                       thumbnail="/static/templates/forest_green.jpg",
                       colors={"primary": "#065F46", "secondary": "#34D399", "accent": "#D1FAE5", "text": "#064E3B"},
                       fonts={"heading": "Josefin Sans", "body": "Karla"},
                       layout_style="organic"),
        ]
    
    def get_all_templates(self) -> List[PPTTemplate]:
        return self.templates
    
    def get_template_by_id(self, template_id: str) -> PPTTemplate:
        return next((t for t in self.templates if t.id == template_id), self.templates[0])
    
    def get_templates_by_category(self, category: str) -> List[PPTTemplate]:
        return [t for t in self.templates if t.category == category]
