from datetime import datetime, timedelta
from typing import Dict, List
from motor.motor_asyncio import AsyncIOMotorDatabase

class AnalyticsService:
    async def get_user_stats(self, db: AsyncIOMotorDatabase, user_id: str) -> Dict:
        total_presentations = await db.presentations.count_documents({"user_id": user_id})
        total_pdfs = await db.presentations.count_documents({"user_id": user_id, "pdf_filename": {"$exists": True}})
        
        recent_activity = await db.presentations.find({"user_id": user_id}).sort("created_at", -1).limit(7).to_list(7)
        
        activity_by_day = {}
        for pres in recent_activity:
            day = pres.get("created_at", datetime.now()).strftime("%Y-%m-%d")
            activity_by_day[day] = activity_by_day.get(day, 0) + 1
        
        return {
            "total_presentations": total_presentations,
            "total_pdfs": total_pdfs,
            "recent_activity": activity_by_day,
            "avg_per_week": round(total_presentations / max(1, (datetime.now() - recent_activity[-1].get("created_at", datetime.now())).days / 7), 1) if recent_activity else 0
        }
    
    async def get_presentation_analytics(self, db: AsyncIOMotorDatabase, user_id: str) -> Dict:
        pipeline = [
            {"$match": {"user_id": user_id}},
            {"$group": {
                "_id": None,
                "total_slides": {"$sum": {"$size": {"$ifNull": ["$slides", []]}}},
                "avg_slides": {"$avg": {"$size": {"$ifNull": ["$slides", []]}}},
            }}
        ]
        result = await db.presentations.aggregate(pipeline).to_list(1)
        
        return {
            "total_slides": result[0]["total_slides"] if result else 0,
            "avg_slides_per_presentation": round(result[0]["avg_slides"], 1) if result else 0,
        }
    
    async def get_template_usage(self, db: AsyncIOMotorDatabase, user_id: str) -> List[Dict]:
        pipeline = [
            {"$match": {"user_id": user_id}},
            {"$group": {"_id": "$template_id", "count": {"$sum": 1}}},
            {"$sort": {"count": -1}},
            {"$limit": 5}
        ]
        return await db.presentations.aggregate(pipeline).to_list(5)
