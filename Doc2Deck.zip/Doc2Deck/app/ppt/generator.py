from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE
import os

class PPTGenerator:
    def __init__(self):
        self.templates = {
            "modern_blue": {
                "colors": {"primary": (37, 99, 235), "secondary": (96, 165, 250), "text": (30, 41, 59), "bg": (255, 255, 255)},
                "fonts": {"title": "Montserrat", "body": "Open Sans"},
                "title_size": 44, "body_size": 20, "layout": "centered"
            },
            "elegant_dark": {
                "colors": {"primary": (248, 250, 252), "secondary": (245, 158, 11), "text": (226, 232, 240), "bg": (15, 23, 42)},
                "fonts": {"title": "Playfair Display", "body": "Lato"},
                "title_size": 48, "body_size": 18, "layout": "left_accent"
            },
            "vibrant_gradient": {
                "colors": {"primary": (139, 92, 246), "secondary": (236, 72, 153), "text": (31, 41, 55), "bg": (255, 255, 255)},
                "fonts": {"title": "Poppins", "body": "Inter"},
                "title_size": 46, "body_size": 22, "layout": "bold"
            },
            "minimal_white": {
                "colors": {"primary": (59, 130, 246), "secondary": (147, 197, 253), "text": (17, 24, 39), "bg": (255, 255, 255)},
                "fonts": {"title": "Roboto", "body": "Roboto"},
                "title_size": 40, "body_size": 18, "layout": "minimal"
            },
            "corporate_green": {
                "colors": {"primary": (5, 150, 105), "secondary": (16, 185, 129), "text": (6, 78, 59), "bg": (255, 255, 255)},
                "fonts": {"title": "Raleway", "body": "Source Sans Pro"},
                "title_size": 42, "body_size": 20, "layout": "professional"
            },
            "tech_purple": {
                "colors": {"primary": (124, 58, 237), "secondary": (167, 139, 250), "text": (31, 41, 55), "bg": (249, 250, 251)},
                "fonts": {"title": "Space Grotesk", "body": "Inter"},
                "title_size": 44, "body_size": 20, "layout": "tech"
            },
            "warm_orange": {
                "colors": {"primary": (234, 88, 12), "secondary": (251, 146, 60), "text": (67, 20, 7), "bg": (255, 255, 255)},
                "fonts": {"title": "Nunito", "body": "Nunito Sans"},
                "title_size": 42, "body_size": 20, "layout": "friendly"
            },
            "ocean_blue": {
                "colors": {"primary": (2, 132, 199), "secondary": (56, 189, 248), "text": (12, 74, 110), "bg": (255, 255, 255)},
                "fonts": {"title": "Merriweather", "body": "Lora"},
                "title_size": 40, "body_size": 18, "layout": "classic"
            },
            "sunset_gradient": {
                "colors": {"primary": (220, 38, 38), "secondary": (245, 158, 11), "text": (31, 41, 55), "bg": (255, 255, 255)},
                "fonts": {"title": "Bebas Neue", "body": "Quicksand"},
                "title_size": 50, "body_size": 22, "layout": "bold"
            },
            "forest_green": {
                "colors": {"primary": (6, 95, 70), "secondary": (52, 211, 153), "text": (6, 78, 59), "bg": (255, 255, 255)},
                "fonts": {"title": "Josefin Sans", "body": "Karla"},
                "title_size": 42, "body_size": 20, "layout": "organic"
            },
        }
    
    def create_presentation(self, notes: str, user_id: int, template_id: str = "modern_blue") -> str:
        prs = Presentation()
        prs.slide_width = Inches(10)
        prs.slide_height = Inches(7.5)
        
        template = self.templates.get(template_id, self.templates["modern_blue"])
        slides_content = self._parse_notes_to_slides(notes)
        
        self._create_title_slide(prs, template)
        for slide_content in slides_content:
            self._create_content_slide(prs, slide_content, template)
        
        output_path = f"uploads/presentation_{user_id}.pptx"
        prs.save(output_path)
        return output_path
    
    def _create_title_slide(self, prs, template):
        blank_layout = prs.slide_layouts[6]
        slide = prs.slides.add_slide(blank_layout)
        
        # Background
        background = slide.background
        fill = background.fill
        fill.solid()
        fill.fore_color.rgb = RGBColor(*template["colors"]["bg"])
        
        # Add decorative shape based on layout
        if template["layout"] in ["bold", "vibrant_gradient"]:
            shape = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(0), Inches(0), Inches(10), Inches(2))
            shape.fill.solid()
            shape.fill.fore_color.rgb = RGBColor(*template["colors"]["primary"])
            shape.line.fill.background()
        
        # Title
        title_box = slide.shapes.add_textbox(Inches(1), Inches(2.5), Inches(8), Inches(1.5))
        title_frame = title_box.text_frame
        title_frame.text = "Generated Presentation"
        title_frame.paragraphs[0].font.size = Pt(template["title_size"])
        title_frame.paragraphs[0].font.bold = True
        title_frame.paragraphs[0].font.color.rgb = RGBColor(*template["colors"]["primary"])
        title_frame.paragraphs[0].alignment = PP_ALIGN.CENTER
        
        # Subtitle
        subtitle_box = slide.shapes.add_textbox(Inches(1), Inches(4.5), Inches(8), Inches(1))
        subtitle_frame = subtitle_box.text_frame
        subtitle_frame.text = "Created with Doc2Deck"
        subtitle_frame.paragraphs[0].font.size = Pt(24)
        subtitle_frame.paragraphs[0].font.color.rgb = RGBColor(*template["colors"]["secondary"])
        subtitle_frame.paragraphs[0].alignment = PP_ALIGN.CENTER
    
    def _create_content_slide(self, prs, slide_content, template):
        blank_layout = prs.slide_layouts[6]
        slide = prs.slides.add_slide(blank_layout)
        
        # Background
        background = slide.background
        fill = background.fill
        fill.solid()
        fill.fore_color.rgb = RGBColor(*template["colors"]["bg"])
        
        # Add decorative elements based on layout
        if template["layout"] == "left_accent":
            accent = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(0), Inches(0), Inches(0.3), Inches(7.5))
            accent.fill.solid()
            accent.fill.fore_color.rgb = RGBColor(*template["colors"]["secondary"])
            accent.line.fill.background()
        elif template["layout"] == "tech":
            for i in range(3):
                circle = slide.shapes.add_shape(MSO_SHAPE.OVAL, Inches(8.5 + i*0.4), Inches(0.2), Inches(0.3), Inches(0.3))
                circle.fill.solid()
                circle.fill.fore_color.rgb = RGBColor(*template["colors"]["secondary"])
                circle.line.fill.background()
        
        # Title with background bar
        title_bg = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(0.5), Inches(0.5), Inches(9), Inches(1))
        title_bg.fill.solid()
        title_bg.fill.fore_color.rgb = RGBColor(*template["colors"]["primary"])
        title_bg.line.fill.background()
        
        title_box = slide.shapes.add_textbox(Inches(0.7), Inches(0.6), Inches(8.5), Inches(0.8))
        title_frame = title_box.text_frame
        title_frame.text = slide_content["title"] or "Content"
        title_frame.paragraphs[0].font.size = Pt(32)
        title_frame.paragraphs[0].font.bold = True
        title_frame.paragraphs[0].font.color.rgb = RGBColor(255, 255, 255)
        
        # Content area
        content_top = 2.0
        content_box = slide.shapes.add_textbox(Inches(1), Inches(content_top), Inches(8), Inches(5))
        text_frame = content_box.text_frame
        text_frame.word_wrap = True
        
        for i, content_item in enumerate(slide_content["content"]):
            if i > 0:
                p = text_frame.add_paragraph()
            else:
                p = text_frame.paragraphs[0]
            
            p.text = "• " + content_item
            p.font.size = Pt(template["body_size"])
            p.font.color.rgb = RGBColor(*template["colors"]["text"])
            p.space_after = Pt(12)
            p.level = 0
    
    def _parse_notes_to_slides(self, notes: str):
        slides = []
        current_slide = {"title": "", "content": []}
        lines = notes.split('\n')
        
        for line in lines:
            line = line.strip()
            if not line:
                continue
            
            if line.startswith('# '):
                if current_slide["title"] or current_slide["content"]:
                    slides.append(current_slide)
                current_slide = {"title": line[2:], "content": []}
            elif line.startswith('## '):
                if current_slide["title"] or current_slide["content"]:
                    slides.append(current_slide)
                current_slide = {"title": line[3:], "content": []}
            elif line.startswith('• ') or line.startswith('- '):
                current_slide["content"].append(line[2:])
            else:
                if len(line) > 10:
                    current_slide["content"].append(line)
        
        if current_slide["title"] or current_slide["content"]:
            slides.append(current_slide)
        
        # Split slides with too much content
        balanced = []
        for slide in slides:
            if len(slide["content"]) > 5:
                chunks = [slide["content"][i:i+5] for i in range(0, len(slide["content"]), 5)]
                for idx, chunk in enumerate(chunks):
                    suffix = f" ({idx+1}/{len(chunks)})" if len(chunks) > 1 else ""
                    balanced.append({"title": slide["title"] + suffix, "content": chunk})
            else:
                balanced.append(slide)
        
        return balanced
