class Chatbot {
    constructor() {
        this.isOpen = false;
        this.messages = [];
        this.init();
    }

    init() {
        this.createChatbotUI();
        this.attachEventListeners();
    }

    createChatbotUI() {
        const container = document.createElement('div');
        container.className = 'chatbot-container';
        container.innerHTML = `
            <div class="chatbot-window" id="chatbotWindow" style="display: none;">
                <div class="chatbot-header">
                    <div class="flex justify-between items-center">
                        <div class="flex items-center gap-2">
                            <i class="fas fa-robot"></i>
                            <span>Doc2Deck Assistant</span>
                        </div>
                        <button onclick="chatbot.close()" class="text-white hover:text-gray-200">
                            <i class="fas fa-times"></i>
                        </button>
                    </div>
                </div>
                <div class="chatbot-messages" id="chatbotMessages">
                    <div class="message-bubble message-bot">
                        Hi! I'm your Doc2Deck assistant. How can I help you create better presentations today?
                    </div>
                </div>
                <div class="chatbot-input-area">
                    <div class="flex gap-2">
                        <input type="text" id="chatbotInput" 
                               class="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                               placeholder="Type your message...">
                        <button onclick="chatbot.sendMessage()" 
                                class="px-4 py-2 bg-gradient-primary text-white rounded-lg hover:opacity-90">
                            <i class="fas fa-paper-plane"></i>
                        </button>
                    </div>
                </div>
            </div>
            <button class="chatbot-button" onclick="chatbot.toggle()">
                <i class="fas fa-comments text-2xl"></i>
            </button>
        `;
        document.body.appendChild(container);
    }

    attachEventListeners() {
        const input = document.getElementById('chatbotInput');
        if (input) {
            input.addEventListener('keypress', (e) => {
                if (e.key === 'Enter') this.sendMessage();
            });
        }
    }

    toggle() {
        this.isOpen = !this.isOpen;
        const window = document.getElementById('chatbotWindow');
        window.style.display = this.isOpen ? 'flex' : 'none';
    }

    close() {
        this.isOpen = false;
        document.getElementById('chatbotWindow').style.display = 'none';
    }

    async sendMessage() {
        const input = document.getElementById('chatbotInput');
        const message = input.value.trim();
        if (!message) return;

        this.addMessage(message, 'user');
        input.value = '';

        this.showTyping();

        try {
            const response = await fetch('/api/chatbot', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ message })
            });
            const data = await response.json();
            this.removeTyping();
            this.addMessage(data.response, 'bot');
        } catch (error) {
            this.removeTyping();
            this.addMessage('Sorry, I encountered an error. Please try again.', 'bot');
        }
    }

    addMessage(text, sender) {
        const messagesDiv = document.getElementById('chatbotMessages');
        const messageDiv = document.createElement('div');
        messageDiv.className = `message-bubble message-${sender}`;
        messageDiv.textContent = text;
        messagesDiv.appendChild(messageDiv);
        messagesDiv.scrollTop = messagesDiv.scrollHeight;
    }

    showTyping() {
        const messagesDiv = document.getElementById('chatbotMessages');
        const typingDiv = document.createElement('div');
        typingDiv.id = 'typingIndicator';
        typingDiv.className = 'message-bubble message-bot';
        typingDiv.innerHTML = '<div class="loading-dots"><span></span><span></span><span></span></div>';
        messagesDiv.appendChild(typingDiv);
        messagesDiv.scrollTop = messagesDiv.scrollHeight;
    }

    removeTyping() {
        const typing = document.getElementById('typingIndicator');
        if (typing) typing.remove();
    }
}

let chatbot;
document.addEventListener('DOMContentLoaded', () => {
    chatbot = new Chatbot();
});
