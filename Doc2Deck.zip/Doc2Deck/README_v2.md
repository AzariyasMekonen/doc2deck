# Doc2Deck v2.0 - Advanced Presentation Generation System

## 🚀 Overview
Doc2Deck is a comprehensive AI-powered platform that transforms PDF documents into beautiful, professional presentations with advanced features including analytics dashboards, AI chatbot assistance, and 10+ premium templates.

## ✨ Key Features

### 🎨 Beautiful Templates
- **10+ Professional Templates** across multiple categories:
  - Business (Modern Blue, Elegant Dark, Corporate Green)
  - Creative (Vibrant Gradient, Warm Orange, Sunset Gradient)
  - Academic (Minimal White, Ocean Blue)
  - Technology (Tech Purple)
  - Nature (Forest Green)
- Each template features custom color schemes and typography
- Premium templates with advanced styling

### 📊 Advanced Analytics Dashboard
- **Real-time Statistics**:
  - Total presentations created
  - PDFs processed
  - Average slides per presentation
  - Activity trends over time
- **Interactive Charts**:
  - Line charts for activity tracking
  - Doughnut charts for template usage
  - Bar charts for overall statistics
- **Performance Metrics**:
  - Weekly averages
  - Usage patterns
  - Template popularity

### 🤖 AI-Powered Chatbot Assistant
- **Intelligent Help System**:
  - Real-time conversation support
  - Context-aware responses
  - Presentation tips and suggestions
  - Feature guidance
- **Floating Chat Interface**:
  - Always accessible from any page
  - Beautiful gradient design
  - Smooth animations
  - Message history

### 🎯 Core Functionality
- **PDF Processing**:
  - Smart text extraction
  - Page range selection
  - Multi-format support
- **AI Content Generation**:
  - Automatic note generation
  - Intelligent slide organization
  - Content optimization
- **Presentation Management**:
  - Save and organize presentations
  - Edit and regenerate
  - Download PowerPoint files
  - Present mode

### 🎨 Modern UI/UX
- **Beautiful Design**:
  - Gradient backgrounds
  - Glass morphism effects
  - Smooth animations
  - Responsive layout
- **Interactive Elements**:
  - Hover effects
  - Card animations
  - Loading states
  - Progress indicators

## 🛠️ Technology Stack

### Backend
- **FastAPI** - Modern Python web framework
- **MongoDB** - NoSQL database with Motor async driver
- **Google Gemini AI** - Advanced AI for content generation
- **PyPDF2 & pdfplumber** - PDF processing
- **python-pptx** - PowerPoint generation

### Frontend
- **Tailwind CSS** - Utility-first CSS framework
- **Chart.js** - Interactive data visualization
- **Font Awesome** - Icon library
- **Custom CSS** - Advanced animations and effects

### AI Services
- **Gemini Pro** - Content generation and chatbot
- **OpenRouter API** - Alternative AI processing

## 📁 Project Structure

```
Doc2Deck/
├── app/
│   ├── ai/
│   │   └── service.py              # AI content generation
│   ├── analytics/
│   │   └── analytics_service.py    # Analytics and metrics
│   ├── auth/
│   │   ├── auth.py                 # Authentication logic
│   │   └── models.py               # Database models
│   ├── chatbot/
│   │   └── chatbot_service.py      # AI chatbot service
│   ├── pdf/
│   │   └── processor.py            # PDF processing
│   ├── ppt/
│   │   └── generator.py            # PowerPoint generation
│   └── templates_mgmt/
│       └── template_manager.py     # Template management
├── static/
│   ├── css/
│   │   └── styles.css              # Custom styles
│   ├── js/
│   │   ├── chatbot.js              # Chatbot functionality
│   │   └── charts.js               # Chart visualizations
│   └── templates/                  # Template thumbnails
├── templates/
│   ├── analytics.html              # Analytics dashboard
│   ├── dashboard.html              # Main dashboard
│   ├── templates_gallery.html      # Template browser
│   ├── upload.html                 # Enhanced upload page
│   └── ...                         # Other pages
├── uploads/                        # User uploads
├── main.py                         # Application entry point
├── requirements.txt                # Python dependencies
└── .env                           # Environment variables
```

## 🚀 Installation

1. **Clone the repository**
```bash
cd Doc2Deck-v2/Doc2Deck
```

2. **Install dependencies**
```bash
pip install -r requirements.txt
```

3. **Configure environment variables**
Edit `.env` file with your credentials:
```env
SECRET_KEY=your-secret-key
GEMINI_API_KEY=your-gemini-api-key
MONGODB_URL=your-mongodb-connection-string
DATABASE_NAME=doc2deck
OPENROUTER_API_KEY=your-openrouter-key
```

4. **Run the application**
```bash
python main.py
```

5. **Access the application**
Open browser to: `http://localhost:8000`

## 📖 Usage Guide

### Creating a Presentation
1. **Upload PDF**: Click "Upload PDF" from dashboard
2. **Select Template**: Choose from 10+ beautiful templates
3. **Configure**: Set title and page range
4. **Generate**: AI processes and creates presentation
5. **Review**: Edit notes and regenerate if needed
6. **Download**: Export as PowerPoint file

### Using Analytics
1. Navigate to Analytics Dashboard
2. View real-time statistics
3. Analyze activity trends
4. Track template usage
5. Monitor productivity metrics

### AI Chatbot
1. Click chatbot button (bottom-right)
2. Ask questions about features
3. Get presentation tips
4. Receive instant guidance
5. Context-aware responses

### Template Gallery
1. Browse 10+ templates
2. Filter by category
3. Preview color schemes
4. Select and apply instantly

## 🎨 Template Categories

### Business Templates
- **Modern Blue**: Clean, professional design
- **Elegant Dark**: Sophisticated dark theme
- **Corporate Green**: Traditional business style

### Creative Templates
- **Vibrant Gradient**: Bold, colorful design
- **Warm Orange**: Friendly, energetic theme
- **Sunset Gradient**: Dynamic gradient effects

### Academic Templates
- **Minimal White**: Clean, simple layout
- **Ocean Blue**: Classic academic style

### Technology Templates
- **Tech Purple**: Modern tech aesthetic

### Nature Templates
- **Forest Green**: Organic, natural theme

## 🔒 Security Features
- JWT-based authentication
- Password hashing with bcrypt
- Secure cookie management
- Environment variable protection
- Input validation

## 📊 Analytics Metrics
- Total presentations created
- PDFs processed count
- Average slides per presentation
- Weekly activity averages
- Template usage statistics
- Activity timeline visualization

## 🤝 Contributing
This is a comprehensive presentation generation system with enterprise-level features. Future enhancements could include:
- Collaboration features
- Cloud storage integration
- Advanced AI customization
- More template designs
- Export format options

## 📝 License
Proprietary - All rights reserved

## 🆘 Support
For issues or questions:
- Check the AI Chatbot for instant help
- Review analytics for usage insights
- Explore template gallery for design options

## 🎯 Version
**v2.0** - Advanced Features Release
- 10+ Beautiful Templates
- Analytics Dashboard
- AI Chatbot Assistant
- Enhanced UI/UX
- Real-time Charts
- Template Management System

---

**Built with ❤️ using FastAPI, MongoDB, and Google Gemini AI**
